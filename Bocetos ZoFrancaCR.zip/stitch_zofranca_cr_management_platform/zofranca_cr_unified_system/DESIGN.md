---
name: ZoFranca CR Unified System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#43474f'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#747780'
  outline-variant: '#c4c6d0'
  surface-tint: '#415f8f'
  primary: '#001430'
  on-primary: '#ffffff'
  primary-container: '#002855'
  on-primary-container: '#7490c3'
  inverse-primary: '#aac7fd'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dfe0e0'
  on-secondary-container: '#616363'
  tertiary: '#00190e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00301e'
  on-tertiary-container: '#00a472'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#aac7fd'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#284775'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-margin: 24px
  gutter: 16px
  padding-card: 20px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is engineered for **ZoFranca CR**, a logistics and administrative backbone for Free Trade Zone management. The brand personality is authoritative, reliable, and highly systematic, reflecting the legal and operational precision required in Costa Rican trade environments.

The visual style follows a **Corporate Modern** aesthetic. It prioritizes data density without sacrificing clarity, utilizing a "Soft SaaS" approach: heavy on whitespace, refined typography, and subtle depth. The interface must feel institutional yet technologically advanced, instilling confidence in institutional stakeholders and regional operators.

## Colors
The palette is anchored by **Deep Navy Blue**, representing stability and corporate trust. **Clean White** and **Light Gray** form the structural foundation, ensuring the interface remains breathable during complex data entry tasks.

- **Primary (#002855):** Used for navigation sidebars, primary action buttons, and active states.
- **Surface (#FFFFFF):** Used for cards, modals, and input fields to ensure maximum contrast.
- **Background (#F8FAFC):** A cool-toned gray to reduce eye strain and provide subtle separation from surface elements.
- **Semantic Accents:** Emerald, Amber, and Crimson are reserved strictly for status indicators (e.g., "Customs Cleared," "Pending Review," "Permit Expired").

## Typography
This design system utilizes **Inter** exclusively to leverage its exceptional legibility in data-heavy SaaS environments. The type scale is tight and functional.

- **Headlines:** Use Bold or Semi-Bold weights with slight negative letter-spacing for a modern, "tucked" professional look.
- **Body:** The default size is 14px (`body-md`) for dashboard tables and forms to maximize information density.
- **Labels:** Use Medium weight (500) for form labels and Semi-Bold (600) for status badges/chips.
- **Mobile:** Large display titles scale down to `headline-lg-mobile` to prevent overflow on portrait devices.

## Layout & Spacing
The layout follows a **Fluid Grid** model with strict 4px increments. 

- **Desktop:** A 12-column grid with 24px margins. Sidebars are fixed at 260px, while the main content area remains fluid.
- **Mobile:** Layout collapses to a single column with 16px horizontal margins. Interactive tables must transition to a "card-list" format where each row becomes a standalone card to maintain accessibility.
- **Spacing Rhythm:** Use `stack-md` (16px) for most vertical gaps between related elements and `stack-lg` (32px) to separate distinct sections or groups of metrics.

## Elevation & Depth
The system uses **Tonal Layering** combined with soft, ambient shadows to create a clear hierarchy.

- **Level 0 (Background):** Light Gray (#F8FAFC), flat.
- **Level 1 (Cards/Surface):** White (#FFFFFF) with a 1px border (#E2E8F0) and a subtle shadow (Y: 2px, Blur: 4px, Opacity: 0.05). This is used for main content containers.
- **Level 2 (Active/Hover):** Increased shadow depth (Y: 4px, Blur: 10px, Opacity: 0.08) to indicate interactivity.
- **Level 3 (Modals/Overlays):** High-diffusion shadows to float elements above the UI scrim.

Avoid heavy black shadows; use the Primary Navy color at very low opacity (5-8%) for shadow tints to maintain a clean, professional appearance.

## Shapes
Following the requirement for **2xl rounded corners**, the system adopts a friendly yet structured shape language.

- **Standard Elements:** 8px (0.5rem) for buttons and inputs.
- **Containers/Cards:** 16px (1rem) for main dashboard widgets and cards.
- **Outer Modals:** 24px (1.5rem) for a distinct "modern app" feel.
- **Status Badges:** Fully rounded (pill) to distinguish them from interactive buttons.

## Components
Consistent implementation of these core components ensures a unified user experience:

- **Buttons:** 
  - *Primary:* Deep Navy background, white text, 8px radius.
  - *Secondary:* White background, Deep Navy border (1px), 8px radius.
  - *Loading:* Replace text with a centered 16px spinner while maintaining button width.
- **Interactive Tables:**
  - Header row uses a subtle gray background (#F1F5F9) with `label-sm` typography.
  - Rows feature a subtle hover state (#F8FAFC).
  - On mobile, hide less critical columns and provide a "Detail" accordion for each row.
- **Status Badges:**
  - High-contrast, low-saturation backgrounds (e.g., light emerald for "Success") with dark-toned text for accessibility.
- **Form Fields:**
  - Inputs use a 1px border (#CBD5E1) which thickens to 2px Primary Navy on focus.
  - Error states use Crimson Red (#DC2626) for both the border and the helper text below.
- **Alert Banners:**
  - Full-width banners at the top of the content area. Use solid colors for critical errors and tinted backgrounds for soft notifications.
- **Metric Cards:**
  - Prominent `headline-lg` for the value, `label-md` for the title, and a small trend indicator (Success or Danger) at the bottom right.