---
name: ZoFranca CR Portal
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002113'
  on-tertiary-container: '#009668'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-label:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 32px
  gutter: 24px
  card-gap: 24px
  input-padding-x: 16px
  input-padding-y: 12px
---

## Brand & Style

The design system is a sophisticated, professional desktop interface designed specifically for the regulatory and compliance environment of Costa Rican Free Zones. It blends the reliability of **Corporate Modernism** with the depth of **Glassmorphism** to create an interface that feels both institutional and technologically advanced.

The aesthetic prioritizes clarity and high-density data management. It utilizes frosted glass effects, translucent layers, and vibrant background blurs to establish a sense of modern hierarchy without sacrificing the seriousness required for financial and legal compliance software. The user experience should feel precise, transparent, and authoritative.

## Colors

The palette is anchored by **Deep Navy (#0F172A)**, providing a sense of stability and institutional trust. **Cobalt Blue (#2563EB)** serves as the primary action color, guiding users through compliance workflows.

- **Primary (Navy):** Used for persistent navigation, sidebars, and high-level headings.
- **Secondary (Cobalt):** Used for primary buttons, active states, and focus indicators.
- **Success (Emerald):** Reserved for "In Compliance" statuses, successful filings, and positive data trends.
- **Alert (Neon Red):** Specifically for missed deadlines, compliance violations, and critical errors.
- **Glass Surfaces:** Utilizes semi-transparent whites with `backdrop-filter: blur(12px)` to create depth over subtle background gradients.

## Typography

This design system utilizes **Inter** for its exceptional legibility in data-heavy environments. The typographic hierarchy is structured to handle complex information architecture, from large dashboard KPIs to dense data table cells.

For technical identifiers (e.g., customs codes, tax IDs), a secondary monospaced font (JetBrains Mono) is used to ensure character distinction. Font weights are kept primarily at 400 for body text and 600 for headings to maintain a clean, professional appearance. Tight letter-spacing is applied to larger headlines to maintain a contemporary feel.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid Grid**. The main sidebar remains fixed at 280px, while the main content area utilizes a 12-column fluid grid that caps at a maximum width of 1600px to ensure readability on ultra-wide monitors.

A strict **8px spacing scale** governs all margins and paddings. 
- **Margins:** External page margins are set to 32px.
- **Gutters:** Standard 24px gutters between dashboard widgets.
- **Reflow:** On smaller desktop viewports (1024px), the 12-column grid collapses 4-column widgets into 6-column spans or full-width blocks depending on content density.

## Elevation & Depth

Hierarchy is established through **Layered Glassmorphism**. Unlike traditional material design which uses black shadows, this design system uses "Light-Injected Shadows"—shadows that are low-opacity but contain a hint of the primary Navy color to feel integrated with the UI.

1.  **Level 0 (Base):** Subtle light-grey background (#F1F5F9) or a very soft linear gradient.
2.  **Level 1 (Cards):** Frosted glass (`rgba(255, 255, 255, 0.7)`) with a 1px border (`rgba(255, 255, 255, 0.4)`) and a 12px blur. 
3.  **Level 2 (Navigation/Toolbars):** Elevated with a subtle shadow (`0 4px 20px rgba(15, 23, 42, 0.08)`).
4.  **Level 3 (Modals/Overlays):** Stronger blur (20px) and a more pronounced shadow to isolate the compliance task from the background data.

## Shapes

The design system uses a **Medium Rounded** approach to balance professional rigidity with modern approachability. 

- **Standard Elements (Buttons, Inputs):** 8px (0.5rem) corner radius.
- **Large Elements (Cards, Modals):** 16px (1rem) corner radius.
- **Information Tags (Chips):** 32px (Pill-shaped) for easy visual distinction from actionable buttons.

All glass surfaces must include a 1px inner stroke to simulate a "beveled edge" typical of high-end glass interfaces, using the `glass_border_hex` defined in the color section.

## Components

### Buttons & Inputs
- **Primary Action:** Solid Cobalt Blue (#2563EB) with white text. No glass effect to ensure maximum contrast for "Submit" or "Sign" actions.
- **Secondary Action:** Ghost style with the primary Navy text and a 1px border.
- **Inputs:** Soft white backgrounds with a subtle inner shadow. Focus states must use a 2px Cobalt Blue outer ring.

### Glass Navigation Bar
The top navigation must be persistent, utilizing a `backdrop-filter: blur(16px)` with a bottom border of 1px `rgba(255, 255, 255, 0.2)`. Links use the Navy color with an active state indicated by a 2px Cobalt underline.

### Data Tables (The Core Component)
- **Header:** Sticky, slightly darker glass effect to distinguish from row data.
- **Rows:** Alternating subtle white-to-transparent backgrounds. On hover, a row should "lift" slightly using a very soft shadow and a 2px Cobalt left-border.
- **Cells:** Use `body-sm` for standard data and `mono-label` for numeric/code-based values.

### Compliance Chips
Used for status monitoring. Emerald Green for "Active/Valid," Neon Red for "Expired/Warning," and a neutral Slate for "Draft/Pending." These are always pill-shaped.

### Floating Cards
Dashboard widgets that use the Glassmorphism treatment. They should never have hard black borders; instead, use the semi-transparent white stroke to define their edges against the background.